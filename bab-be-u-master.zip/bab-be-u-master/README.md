# BAB BE U
bab be u be puzle gam wher ruls u folow r prenset as blok u intreact with.. by manpuilating tem, u chang how gam work, repupos thing u find in levl an cuase suprisng itneracton!!

[help bab crew fix nasty bugs !!!](https://github.com/lilybeevee/bab-be-u/projects/1)

[hep bab crew implement new cool fechures!!1](https://github.com/lilybeevee/bab-be-u/projects/2)

## how do?
firs, donload love2d!!
nex, how run gam: https://love2d.org/wiki/Getting_Started#Running_Games

## screnshoot pls!!!!
ok!!, here u go!!!!!
![img3](./docs/img3.png "mennu!!!")

![lvl1](./docs/lvl1.png "xwx what's this?")

![lvl2](./docs/lvl2.png "roguen't floor 2")

![lvl3](./docs/lvl3.png "n'tn't")

![lvl4](./docs/lvl4.png "carrier")

![lvl5](./docs/lvl5.png "ise climers")

## dev info !!!!!!
for build ver (in main menu at the top left), you must add a hook to your .git folder, [click here for more info](https://gist.github.com/sg-s/2ddd0fe91f6037ffb1bce28be0e74d4e)
